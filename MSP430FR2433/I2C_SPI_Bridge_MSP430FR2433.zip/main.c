//******************************************************************************
//  MSP430FR2433 - I2C to SPI bridge
//
//  Description: This demo serves as an interface between an I2C and SPI bus.
//  ACLK = default REFO ~32768Hz, MCLK = SMCLK = DCODIV/2 = 8 MHz.
//
//   /|\  /|\
//   10k  10k          MSP430FR2433
//    |    |   ----------------------------
//  <-|----|->|P1.2/UCB0SDA           P1.7/|---> CS#
//    |       |                P1.6/UCA0CLK|---> CLK
//    |       |               P1.5/UCA0SOMI|<--- POCI
//  --|------>|P1.3/UCB0SCL   P1.4/UCA0SIMO|---> PICO
//            |                            |
//     INT<---|P1.1                    P1.0|---> D/C#
//
//   Based on original code by:
//   Ryan Brown
//   Texas Instruments Inc.
//   September 2017
//   Built Code Composer Studio v7.2
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------
uint8_t I2CRXData[201] = {0x00};                    // I2C data buffer (ID plus data bytes)
uint8_t SPIRXData[200] = {0x00};                    // SPI data buffer (up to 200 data)
uint8_t I2Ccount = 0x00;                            // I2C buffer counter
uint8_t SPIcount = 0x00;                            // SPI data counter

int main(void)
{
  WDTCTL = WDTPW | WDTHOLD;                         // disable watchdog

  __bis_SR_register(SCG0);                          // disable FLL
  CSCTL3 |= SELREF__REFOCLK;                        // Set REFO as FLL reference source
  CSCTL0 = 0;                                       // clear DCO and MOD registers
  CSCTL1 &= ~(DCORSEL_7);                           // Clear DCO frequency select bits first
  CSCTL5 |= DIVM__2;                                // Divide MCLK by 2 (8 MHz)
  CSCTL1 |= DCORSEL_5;                              // Set DCO = 16MHz
  CSCTL2 = FLLD_0 + 487;                            // DCOCLKDIV = 16MHz
  __delay_cycles(3);
  __bic_SR_register(SCG0);                          // enable FLL
  while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));        // FLL locked

  CSCTL4 = SELMS__DCOCLKDIV | SELA__REFOCLK;        // set default REFO(~32768Hz) as ACLK source, ACLK = 32768Hz
                                                    // default DCOCLKDIV as MCLK and SMCLK source

  // Configure GPIO
  P1SEL0 |= BIT2 | BIT3 | BIT4 | BIT5 | BIT6;       // I2C & SPI pin functions
  P1DIR |= BIT0 | BIT1 | BIT7;                      // D/C, INT & CS pins
  P1OUT |= BIT0 | BIT1 | BIT7;                      // Inactive high

  // Disable the GPIO power-on default high-impedance mode to activate
  // previously configured port settings
  PM5CTL0 &= ~LOCKLPM5;

  // Configure USCI_B0 for I2C mode
  UCB0CTLW0 = UCSWRST;                              // Software reset enabled
  UCB0CTLW0 |= UCMODE_3 | UCSYNC;                   // I2C mode, sync mode
  UCB0I2COA0 = 0x48 | UCOAEN;                       // own address is 0x48 + enable
  UCB0CTLW0 &= ~UCSWRST;                            // clear reset register
  UCB0IE |= UCTXIE0 | UCRXIE0 | UCSTPIE | UCSTTIE;  // transmit, receive,stop, & start

  //Configure USCI_A0 for SPI mode
  UCA0CTLW0 |= UCSWRST;                             // **Put state machine in reset**
                                                    // 3-pin, 8-bit SPI master
  UCA0CTLW0 |= UCMST|UCSYNC|UCCKPH|UCMSB|UCMODE_0;
                                                    // Data valid first, clock high, MSB
  UCA0CTLW0 |= UCSSEL__SMCLK;                       // Select SMCLK
  UCA0BR0 = 0x08;                                   // BRCLK = SMCLK/8 = 1 MHz
  UCA0BR1 = 0;                                      //
  UCA0MCTLW = 0;                                    // No modulation
  UCA0CTLW0 &= ~UCSWRST;                            // **Initialize USCI state machine**
  UCA0IE |= UCRXIE;                                 // Enable USCI_A0 RX interrupt

  unsigned char loop = 0x00;

  while(1)
  {
    __bis_SR_register(LPM3_bits | GIE);             // Enter LPM3 w/ interrupts
    switch(I2CRXData[0])                            // Function IDs
    {
        case 0x00:                                  // Command 'Register'
            P1OUT &= ~BIT0;                         // Set D/C# low
            P1OUT &= ~BIT7;                         // Set CS low
            for (loop = 1; loop < I2Ccount; loop++) // Send all but the ID byte
            {
                while (!(UCA0IFG&UCTXIFG));         // Wait for UCTXBUF to clear
                UCA0TXBUF = I2CRXData[loop];        // Send out I2C data on SPI
            }
            while ((UCA0STATW&UCBUSY));             // Wait for last byte to send
            P1OUT |= BIT7;                          // Set CS high
            P1OUT &= ~BIT1;                         // Set INT low
            break;
        case 0x01:                                  // Data 'Register'
            P1OUT |= BIT0;                          // Set D/C# high
            P1OUT &= ~BIT7;                         // Set CS low
            for (loop = 1; loop < I2Ccount; loop++) // Send all but the ID byte
            {
                while (!(UCA0IFG&UCTXIFG));         // Wait for UCTXBUF to clear
                UCA0TXBUF = I2CRXData[loop];        // Send out I2C data on SPI
            }
            while ((UCA0STATW&UCBUSY));             // Wait for last byte to send
            P1OUT |= BIT7;                          // Set CS high
            P1OUT &= ~BIT1;                         // Set INT low
            break;
        case 0xFF:                                  // Clear Interrupt
            P1OUT |= BIT1;                          // Set INT high
            break;
        default: break;
    }
  }
}

//------------------------------------------------------------------------------
// eUSCI_A0 interrupt service routine for SPI master communication.
//------------------------------------------------------------------------------
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
  switch(__even_in_range(UCA0IV,USCI_SPI_UCTXIFG))
  {
    case USCI_SPI_UCRXIFG:                          // All that matters is RXIFG
        SPIRXData[SPIcount++] = UCA0RXBUF;          // Store received SPI data
        break;
    default: break;
  }
}

//------------------------------------------------------------------------------
// eUSCI_B0 interrupt service routine for I2C slave communication.
//------------------------------------------------------------------------------
#pragma vector = USCI_B0_VECTOR
__interrupt void USCIB0_ISR(void)
{
  switch(__even_in_range(UCB0IV, USCI_I2C_UCBIT9IFG))
  {
    case USCI_I2C_UCSTTIFG:                 // Vector 6: STTIFG
      I2Ccount = 0;                         // Reset counters with sequence start
      SPIcount = 0;
      UCB0IFG &= ~UCSTTIFG;                 // Clear start condition int flag
      break;
    case USCI_I2C_UCSTPIFG:                 // Vector 8: STPIFG
      UCB0IFG &= ~UCSTPIFG;                 // Clear stop condition int flag
      __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3 to service main
      break;
    case USCI_I2C_UCRXIFG0:                 // Vector 24: RXIFG0
        I2CRXData[I2Ccount++] = UCB0RXBUF;  // Store received I2C data
        break;
    case USCI_I2C_UCTXIFG0:                 // Vector 26: TXIFG0
       UCB0TXBUF = SPIRXData[I2Ccount++];   // Send out SPI data on I2C
       break;
    default: break;
  }
}

